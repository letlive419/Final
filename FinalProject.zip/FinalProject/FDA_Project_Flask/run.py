from FDA_Project_Flask import app

if __name__ == '__main__':
    app.run()